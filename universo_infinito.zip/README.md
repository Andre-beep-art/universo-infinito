# Universo Infinito 🌌

Este es un sitio web interactivo educativo sobre galaxias, estrellas, planetas y el universo.

## Cómo publicarlo en línea

### 📌 Opción 1: GitHub Pages
1. Crea una cuenta en [GitHub](https://github.com).
2. Crea un nuevo repositorio (ej: `universo-infinito`).
3. Sube el archivo `index.html`.
4. Ve a Settings > Pages > y selecciona `main` como rama y `/ (root)` como carpeta.
5. Tu sitio estará disponible en `https://<tu_usuario>.github.io/universo-infinito`.

### 🚀 Opción 2: Netlify
1. Ve a [https://app.netlify.com](https://app.netlify.com).
2. Arrastra el archivo `index.html`.
3. Netlify te dará una URL para ver tu sitio en línea al instante.

---

Desarrollado por ti con la ayuda de ChatGPT ✨
